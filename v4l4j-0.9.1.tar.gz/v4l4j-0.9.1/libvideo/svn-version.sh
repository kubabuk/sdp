#!/bin/bash
echo "#define VER_REV \"1\"" > version.h

